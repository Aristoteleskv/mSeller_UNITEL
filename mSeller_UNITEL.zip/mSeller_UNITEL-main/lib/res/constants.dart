// ignore_for_file: non_constant_identifier_names
class ConstantAssets {
  final String logo = "assets/logos/logo.png";
  final String logo_w = "assets/logos/logomini.png";
}
