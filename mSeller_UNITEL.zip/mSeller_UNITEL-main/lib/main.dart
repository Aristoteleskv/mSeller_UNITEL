import 'package:flutter/material.dart';
import 'package:unitel_recargas/routes/routes.dart';

void main() {
  runApp(const Routes());
}
